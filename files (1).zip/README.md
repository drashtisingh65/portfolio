# Drashti Singh – Portfolio

Vanilla HTML/CSS/JS, no build step.

```
portfolio/
├── index.html
├── css/style.css
├── js/main.js          <- links + contact form settings at the top
├── assets/
│   ├── profile-placeholder.svg
│   └── certificates/   (your 5 certificates)
└── README.md
```

## Run locally
Open `index.html` in a browser, or for a local server: `python -m http.server 8000` then visit http://localhost:8000

## Customize
- **Photo:** add `assets/profile.jpg` (square, ~800px) and change the `<img src>` in the hero section of `index.html`.
- **LinkedIn / GitHub:** edit `CONFIG` at the top of `js/main.js`.
- **Colors:** change the variables in `:root` at the top of `css/style.css`.
- **New certificate:** copy one `<button class="cert ...">` block in `index.html` and update the image path and text.
- **Skills:** copy a `<article class="skill ...">` card. Icons come from [Devicon](https://devicon.dev).

## Make the contact form work
Without setup, the form opens the visitor's email app addressed to you (works anywhere).
For real submissions: create a free form at https://formspree.io, copy its URL (`https://formspree.io/f/xxxx`) and paste it into `CONFIG.formEndpoint` in `js/main.js`. Netlify Forms is an alternative if you deploy there.

## Deploy
**Netlify (easiest):** go to app.netlify.com/drop and drag the `portfolio` folder in. You get a live URL immediately.
**Vercel:** push the folder to a GitHub repo, then at vercel.com choose *Add New → Project*, import the repo, leave framework as "Other", and click Deploy.
**GitHub Pages:** push to a repo, then Settings → Pages → deploy from the `main` branch.
